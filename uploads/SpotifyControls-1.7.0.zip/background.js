/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Bus = (function () {
    function Bus() {
        var _this = this;
        this._subscriptions = [];
        chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
            if (typeof request.type === "undefined")
                return;
            _this._subscriptions
                .filter(function (s) {
                return s.type === request.type;
            })
                .forEach(function (s) {
                s.callback(request.message);
            });
        });
    }
    Bus.prototype.on = function (type, callback) {
        this._subscriptions.push({ type: type, callback: callback });
    };
    Bus.prototype.send = function (type, message) {
        this._subscriptions
            .filter(function (s) { return s.type === type; })
            .forEach(function (s) {
            s.callback(message);
        });
        chrome.runtime.sendMessage({ type: type, message: message }, function (response) { });
    };
    return Bus;
}());
exports.Bus = Bus;


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var Storage = (function () {
    function Storage() {
    }
    Storage.Get = function (key) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2, new Promise(function (resolve, reject) {
                        chrome.storage.local.get(key, function (flag) {
                            resolve(flag.lyric);
                        });
                    })];
            });
        });
    };
    Storage.Set = function (key, value) {
        chrome.storage.local.set((_a = {}, _a[key] = value, _a));
        var _a;
    };
    Storage.Remove = function (key) {
        chrome.storage.local.remove(key);
    };
    return Storage;
}());
exports.Storage = Storage;


/***/ }),
/* 3 */,
/* 4 */,
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _this = this;
Object.defineProperty(exports, "__esModule", { value: true });
var asynchrome_1 = __webpack_require__(6);
var message_bus_1 = __webpack_require__(1);
var storage_1 = __webpack_require__(2);
var utils_1 = __webpack_require__(7);
var Process = (function () {
    function Process() {
        this._bus = new message_bus_1.Bus();
        this.heartBeatInterval = null;
        this.tabId = null;
        this._cacheArtist = null;
        this._cacheTitle = null;
        this.registerHotKeys();
        this.subscribe();
    }
    Process.prototype.plantAgent = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var tabs;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, asynchrome_1.Tabs.query({ url: "https://player.spotify.com/*" })];
                    case 1:
                        tabs = _a.sent();
                        if (!(tabs.length < 1)) return [3, 3];
                        return [4, asynchrome_1.Tabs.query({ url: "https://play.spotify.com/*" })];
                    case 2:
                        tabs = _a.sent();
                        _a.label = 3;
                    case 3:
                        if (!(tabs.length < 1)) return [3, 5];
                        return [4, asynchrome_1.Tabs.query({ url: "https://open.spotify.com/*" })];
                    case 4:
                        tabs = _a.sent();
                        _a.label = 5;
                    case 5:
                        if (tabs.length < 1) {
                            this._bus.send("idea.agent.lost");
                            return [2];
                        }
                        return [4, asynchrome_1.Tabs.executeScript(tabs[0].id, { file: "agent.js" })];
                    case 6:
                        _a.sent();
                        this._bus.send("idea.agent.planted", { tabId: tabs[0].id });
                        clearInterval(this._heartBeatInterval);
                        (function () { return __awaiter(_this, void 0, void 0, function () { return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4, this.heartBeat()];
                                case 1:
                                    _a.sent();
                                    return [2];
                            }
                        }); }); })();
                        this._heartBeatInterval = setInterval(function () {
                            (function () { return __awaiter(_this, void 0, void 0, function () { return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4, this.heartBeat()];
                                    case 1:
                                        _a.sent();
                                        return [2];
                                }
                            }); }); })();
                        }, 700);
                        return [2];
                }
            });
        });
    };
    Process.prototype.registerHotKeys = function () {
        var _this = this;
        chrome.commands.onCommand.addListener(function (cmd) {
            switch (cmd) {
                case "player-toggle":
                    _this._bus.send("idea.cmd.player.toggle");
                    break;
                case "player-next":
                    _this._bus.send("idea.cmd.player.next");
                    break;
                case "player-previous":
                    _this._bus.send("idea.cmd.player.previous");
                    break;
                case "player-mute":
                    _this._bus.send("idea.cmd.player.mute");
                    break;
                case "player-shuffle":
                    _this._bus.send("idea.cmd.player.shuffle");
                    break;
                case "player-repeat":
                    _this._bus.send("idea.cmd.player.repeat");
                    break;
                case "player-save":
                    _this._bus.send("idea.cmd.player.save");
                    break;
                default:
                    break;
            }
        });
        chrome.notifications.onClicked.addListener(function (evt) {
            _this._bus.send("idea.cmd.player.next");
        });
    };
    Process.prototype.subscribe = function () {
        var _this = this;
        this._bus.on("idea.agent.planted", function (evt) {
            _this.tabId = evt.tabId;
        });
        this._bus.on("idea.cmd.player.toggle", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Toggle()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.next", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Next()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.previous", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Previous()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.shuffle", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Shuffle()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.repeat", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Repeat()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.mute", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Mute()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.save", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Save()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.track.changed", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            var options, notificationId;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        options = {
                            type: "basic",
                            iconUrl: evt.art,
                            title: evt.artist,
                            message: evt.title,
                            contextMessage: "(click to skip)",
                            isClickable: true
                        };
                        return [4, asynchrome_1.Notifications.create(utils_1.newGuid(), options)];
                    case 1:
                        notificationId = _a.sent();
                        return [4, utils_1.delay(5000)];
                    case 2:
                        _a.sent();
                        return [4, asynchrome_1.Notifications.clear(notificationId)];
                    case 3:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.track.changed", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, this.getLyrics(evt.artist, evt.title)];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
    };
    Process.prototype.getLyrics = function (artist, title) {
        return __awaiter(this, void 0, void 0, function () {
            var response, data, song, lyric, lines, lyr, i;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, window.fetch("http://lyrics.wikia.com/api.php?action=lyrics&artist=" + artist + "&song=" + title + "&fmt=json")];
                    case 1:
                        response = _a.sent();
                        return [4, response.text()];
                    case 2:
                        data = _a.sent();
                        song = eval(data);
                        lyric = song;
                        if (!(lyric.lyrics.toLowerCase() === "not found")) return [3, 5];
                        storage_1.Storage.Remove("lyric");
                        if (!(title.indexOf(" - ") > -1)) return [3, 4];
                        return [4, this.getLyrics(artist, title.substring(0, title.indexOf(" - ")))];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [3, 6];
                    case 5:
                        lines = lyric.lyrics
                            .split(/\r\n|\r|\n/)
                            .filter(function (line) { return line.replace(/\s/g, "") === "" ? false : true; })
                            .splice(0, 4);
                        lyr = "";
                        for (i in lines) {
                            if (lines.hasOwnProperty(i)) {
                                if (lyr.length > 120)
                                    break;
                                lyr += ("\r\n" + lines[i].replace("[...]", ""));
                            }
                        }
                        lyric.lyrics = lyr + "..";
                        storage_1.Storage.Set("lyric", lyric);
                        _a.label = 6;
                    case 6: return [2];
                }
            });
        });
    };
    Process.prototype.heartBeat = function () {
        return __awaiter(this, void 0, void 0, function () {
            var tab, tracks, track;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!!this.tabId) return [3, 2];
                        return [4, this.plantAgent()];
                    case 1:
                        _a.sent();
                        return [2];
                    case 2: return [4, asynchrome_1.Tabs.get(this.tabId)];
                    case 3:
                        tab = _a.sent();
                        if (!!tab) return [3, 5];
                        return [4, this.plantAgent()];
                    case 4:
                        _a.sent();
                        return [2];
                    case 5: return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.GetTrackInfo()" })];
                    case 6:
                        tracks = _a.sent();
                        if (!(!tracks || tracks.length < 1 || !tracks[0])) return [3, 8];
                        return [4, this.plantAgent()];
                    case 7:
                        _a.sent();
                        return [2];
                    case 8:
                        track = tracks[0];
                        this._bus.send("idea.track.updated", track);
                        if (this._cacheArtist !== track.artist || this._cacheTitle !== track.title) {
                            this._cacheArtist = track.artist;
                            this._cacheTitle = track.title;
                            this._bus.send("idea.track.changed", track);
                        }
                        return [2];
                }
            });
        });
    };
    return Process;
}());
var process = new Process();
(function () { return __awaiter(_this, void 0, void 0, function () { return __generator(this, function (_a) {
    switch (_a.label) {
        case 0: return [4, process.plantAgent()];
        case 1:
            _a.sent();
            return [2];
    }
}); }); })();


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Tabs = (function () {
    function Tabs() {
    }
    Tabs.get = function (tabId) {
        return new Promise(function (resolve, reject) {
            chrome.tabs.get(tabId, function (tab) {
                resolve(tab);
            });
        });
    };
    Tabs.query = function (queryInfo) {
        return new Promise(function (resolve, reject) {
            chrome.tabs.query(queryInfo, function (tabs) {
                resolve(tabs);
            });
        });
    };
    Tabs.executeScript = function (tabId, details) {
        return new Promise(function (resolve, reject) {
            chrome.tabs.executeScript(tabId, details, function (tabs) {
                resolve(tabs);
            });
        });
    };
    return Tabs;
}());
exports.Tabs = Tabs;
var Notifications = (function () {
    function Notifications() {
    }
    Notifications.clear = function (notificationId) {
        return new Promise(function (resolve, reject) {
            chrome.notifications.clear(notificationId, function (isCleared) {
                resolve(isCleared);
            });
        });
    };
    Notifications.create = function (notificationId, options) {
        return new Promise(function (resolve, reject) {
            chrome.notifications.create(notificationId, options, function (id) {
                resolve(id);
            });
        });
    };
    return Notifications;
}());
exports.Notifications = Notifications;


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function newGuid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + "-" + s4() + "-" + s4() + "-" +
        s4() + "-" + s4() + s4() + s4();
}
exports.newGuid = newGuid;
function delay(ms) {
    return new Promise(function (resolve) {
        setTimeout(resolve, ms);
    });
}
exports.delay = delay;


/***/ })
/******/ ]);
//# sourceMappingURL=background.js.map