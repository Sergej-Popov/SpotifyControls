/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 3);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Logger = (function () {
    function Logger(name) {
        this._name = name;
    }
    Object.defineProperty(Logger.prototype, "_level", {
        get: function () {
            return window.logLevel || LogLevel.Debug;
        },
        enumerable: true,
        configurable: true
    });
    Logger.prototype.debug = function (message, params) {
        if (this._level > LogLevel.Debug)
            return;
        console.log(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    Logger.prototype.info = function (message, params) {
        if (this._level > LogLevel.Info)
            return;
        console.info(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    Logger.prototype.warn = function (message, params) {
        if (this._level > LogLevel.Warn)
            return;
        console.warn(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    Logger.prototype.error = function (message, params) {
        if (this._level > LogLevel.Error)
            return;
        console.error(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    return Logger;
}());
exports.Logger = Logger;
var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["None"] = 0] = "None";
    LogLevel[LogLevel["Debug"] = 1] = "Debug";
    LogLevel[LogLevel["Info"] = 2] = "Info";
    LogLevel[LogLevel["Warn"] = 3] = "Warn";
    LogLevel[LogLevel["Error"] = 4] = "Error";
})(LogLevel = exports.LogLevel || (exports.LogLevel = {}));


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Bus = (function () {
    function Bus() {
        var _this = this;
        this._subscriptions = [];
        chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
            if (typeof request.type === "undefined")
                return;
            _this._subscriptions
                .filter(function (s) {
                return s.type === request.type;
            })
                .forEach(function (s) {
                s.callback(request.message);
            });
        });
    }
    Bus.prototype.on = function (type, callback) {
        this._subscriptions.push({ type: type, callback: callback });
    };
    Bus.prototype.send = function (type, message) {
        this._subscriptions
            .filter(function (s) { return s.type === type; })
            .forEach(function (s) {
            s.callback(message);
        });
        chrome.runtime.sendMessage({ type: type, message: message }, function (response) { });
    };
    return Bus;
}());
exports.Bus = Bus;


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var Storage = (function () {
    function Storage() {
    }
    Storage.Get = function (key) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2, new Promise(function (resolve, reject) {
                        chrome.storage.local.get(key, function (flag) {
                            resolve(flag[key]);
                        });
                    })];
            });
        });
    };
    Storage.Set = function (key, value) {
        chrome.storage.local.set((_a = {}, _a[key] = value, _a));
        var _a;
    };
    Storage.Remove = function (key) {
        chrome.storage.local.remove(key);
    };
    return Storage;
}());
exports.Storage = Storage;


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var _this = this;
Object.defineProperty(exports, "__esModule", { value: true });
var logger_1 = __webpack_require__(0);
var message_bus_1 = __webpack_require__(1);
var resources_1 = __webpack_require__(4);
var storage_1 = __webpack_require__(2);
var Main = (function () {
    function Main() {
        this._logger = new logger_1.Logger("Main");
        this._logger.debug("ctor");
        this._bus = new message_bus_1.Bus();
    }
    Main.prototype.initialize = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this._logger.debug("init");
                        this._bus.on("idea.track.updated", function (evt) { return __awaiter(_this, void 0, void 0, function () { return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4, this.updateTrackInfo(evt)];
                                case 1:
                                    _a.sent();
                                    return [2];
                            }
                        }); }); });
                        this._bus.on("idea.track.changed", function (evt) { return __awaiter(_this, void 0, void 0, function () { return __generator(this, function (_a) {
                            switch (_a.label) {
                                case 0: return [4, this.updateTrack(evt)];
                                case 1:
                                    _a.sent();
                                    return [2];
                            }
                        }); }); });
                        return [4, this.hideActions()];
                    case 1:
                        _a.sent();
                        this.registerClicks();
                        this.printConsoleGreetings();
                        return [2];
                }
            });
        });
    };
    Main.prototype.updateTrackInfo = function (track) {
        return __awaiter(this, void 0, void 0, function () {
            var lyric;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this._logger.debug("updating tack info", track);
                        document.querySelector("#main").classList.remove("no-player");
                        document.querySelector("#track-progress").style.width =
                            (document.querySelector("#track-bar").clientWidth * track.progress) + "px";
                        document.querySelector("#volume-level").style.width =
                            (document.querySelector("#volume-bar").clientWidth * track.volume) + "px";
                        document.querySelector("#track-elapsed").innerHTML = track.elapsed;
                        track.shuffle_on ? document.querySelector("#shuffle").classList.add("active") : document.querySelector("#shuffle").classList.remove("active");
                        track.repeat_on ? document.querySelector("#repeat").classList.add("active") : document.querySelector("#repeat").classList.remove("active");
                        if (track.mute_on) {
                            document.querySelector("#mute").classList.add("fa-volume-off");
                            document.querySelector("#mute").classList.remove("fa-volume-up");
                        }
                        else {
                            document.querySelector("#mute").classList.add("fa-volume-up");
                            document.querySelector("#mute").classList.remove("fa-volume-off");
                        }
                        if (track.is_playing) {
                            document.querySelector("#toggle").classList.add("fa-pause-circle-o");
                            document.querySelector("#toggle").classList.remove("fa-play-circle-o");
                        }
                        else {
                            document.querySelector("#toggle").classList.add("fa-play-circle-o");
                            document.querySelector("#toggle").classList.remove("fa-pause-circle-o");
                        }
                        if (track.is_saved) {
                            document.querySelector("#save").classList.add("fa-check");
                            document.querySelector("#save").classList.remove("fa-plus");
                        }
                        else {
                            document.querySelector("#save").classList.add("fa-plus");
                            document.querySelector("#save").classList.remove("fa-check");
                        }
                        document.querySelector("#track-artist").innerHTML = track.artist;
                        document.querySelector("#track-title").innerHTML = track.title;
                        if (!!track.art)
                            document.querySelector("#track-art").setAttribute("src", track.art);
                        document.querySelector("#track-length").innerHTML = track.length;
                        return [4, storage_1.Storage.Get("lyric")];
                    case 1:
                        lyric = _a.sent();
                        if (lyric) {
                            document.querySelector("#lyrics-link").setAttribute("href", lyric.url);
                            document.querySelector("#lyrics-text").innerHTML = lyric.lyrics;
                            document.querySelector("#lyrics").classList.remove("hidden");
                        }
                        else {
                            document.querySelector("#lyrics").classList.add("hidden");
                        }
                        return [2];
                }
            });
        });
    };
    Main.prototype.updateTrack = function (track) {
        this._logger.info("updating tack", track);
        document.querySelector("#main").classList.remove("no-player");
        document.querySelector("#track-artist").innerHTML = track.artist;
        document.querySelector("#track-title").innerHTML = track.title;
        document.querySelector("#track-art").setAttribute("src", track.art);
        document.querySelector("#lyrics").classList.add("hidden");
    };
    Main.prototype.hideActions = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: return [4, storage_1.Storage.Get("rated")];
                    case 1:
                        if (_b.sent())
                            document.querySelector("#rate-outer").style.display = "none";
                        return [4, storage_1.Storage.Get("donated")];
                    case 2:
                        if (_b.sent())
                            document.querySelector("#donation").style.display = "none";
                        _a = document.querySelector("#settings-notification");
                        return [4, storage_1.Storage.Get("notifications-disabled")];
                    case 3:
                        _a.checked = !(_b.sent());
                        return [2];
                }
            });
        });
    };
    Main.prototype.registerClicks = function () {
        return __awaiter(this, void 0, void 0, function () {
            var _this = this;
            var controls, i;
            return __generator(this, function (_a) {
                controls = document.getElementsByClassName("control");
                for (i = 0; i < controls.length; i++) {
                    controls[i].addEventListener("click", function (evt) {
                        _this._logger.debug("click: " + evt.srcElement.id);
                        _this._bus.send("idea.cmd.player." + evt.srcElement.id);
                    });
                }
                document.querySelector("#notification a").addEventListener("click", function (evt) {
                    _this._logger.debug("click: notification");
                    chrome.tabs.create({ url: resources_1.Resources.urlSpotify });
                    evt.preventDefault();
                });
                document.querySelector("#settings-btn").addEventListener("click", function (evt) {
                    _this._logger.debug("click: settings");
                    document.querySelector("#settings").classList.toggle("open");
                    evt.preventDefault();
                });
                document.querySelector("#hotkeys-lnk").addEventListener("click", function (evt) {
                    _this._logger.debug("click: hotkeys");
                    chrome.tabs.create({ url: resources_1.Resources.urlChromeCommands });
                    evt.preventDefault();
                });
                document.querySelector("#contribute").addEventListener("click", function (evt) {
                    _this._logger.debug("click: contribute");
                    chrome.tabs.create({ url: resources_1.Resources.urlOss });
                    evt.preventDefault();
                });
                document.querySelector("#paypal").addEventListener("click", function (evt) {
                    _this._logger.debug("click: paypal");
                    chrome.tabs.create({ url: resources_1.Resources.urlPayPal });
                    storage_1.Storage.Set("donated", true);
                    evt.preventDefault();
                });
                document.querySelector("#rate").addEventListener("click", function (evt) {
                    _this._logger.debug("click: rate");
                    chrome.tabs.create({ url: resources_1.Resources.urlReviews });
                    storage_1.Storage.Set("rated", true);
                    evt.preventDefault();
                });
                document.querySelector("#settings-notification").addEventListener("change", function (evt) {
                    var enabled = evt.target.checked;
                    _this._logger.info("change: notifications enabled: " + enabled);
                    storage_1.Storage.Set("notifications-disabled", !enabled);
                    evt.preventDefault();
                });
                return [2];
            });
        });
    };
    Main.prototype.printConsoleGreetings = function () {
        this._logger.info(resources_1.Resources.msgDontHack);
        this._logger.info(resources_1.Resources.msgBuyBeer);
        this._logger.info(resources_1.Resources.msgRate);
    };
    return Main;
}());
document.addEventListener("DOMContentLoaded", function () { return __awaiter(_this, void 0, void 0, function () {
    var main;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                main = new Main();
                return [4, main.initialize()];
            case 1:
                _a.sent();
                return [2];
        }
    });
}); });


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Resources = (function () {
    function Resources() {
    }
    Resources.urlSpotify = "http://play.spotify.com";
    Resources.urlOss = "https://github.com/Sergej-Popov/SpotifyControls";
    Resources.urlPayPal = "https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=TRUHY87YGGRLY";
    Resources.urlReviews = "https://chrome.google.com/webstore/detail/spotify-web-app-playback/goikghbjckploljhlfmjjfggccmlnbea/reviews";
    Resources.urlChromeCommands = "chrome://extensions/configureCommands";
    Resources.msgDontHack = "No need to hack around.. This app is open source: " + Resources.urlOss;
    Resources.msgBuyBeer = "\"Learned a thing or two? Buy me a beer: " + Resources.urlPayPal + " (PayPal donation)\"";
    Resources.msgRate = "And don't forget to rate! " + Resources.urlReviews;
    return Resources;
}());
exports.Resources = Resources;


/***/ })
/******/ ]);
//# sourceMappingURL=popup.js.map