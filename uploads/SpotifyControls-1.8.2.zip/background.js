/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 5);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Logger = (function () {
    function Logger(name) {
        this._name = name;
    }
    Object.defineProperty(Logger.prototype, "_level", {
        get: function () {
            return window.logLevel || LogLevel.Warn;
        },
        enumerable: true,
        configurable: true
    });
    Logger.prototype.debug = function (message, params) {
        if (this._level > LogLevel.Debug)
            return;
        console.log(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    Logger.prototype.info = function (message, params) {
        if (this._level > LogLevel.Info)
            return;
        console.info(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    Logger.prototype.warn = function (message, params) {
        if (this._level > LogLevel.Warn)
            return;
        console.warn(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    Logger.prototype.error = function (message, params) {
        if (this._level > LogLevel.Error)
            return;
        console.error(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    return Logger;
}());
exports.Logger = Logger;
var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["None"] = 0] = "None";
    LogLevel[LogLevel["Debug"] = 1] = "Debug";
    LogLevel[LogLevel["Info"] = 2] = "Info";
    LogLevel[LogLevel["Warn"] = 3] = "Warn";
    LogLevel[LogLevel["Error"] = 4] = "Error";
})(LogLevel = exports.LogLevel || (exports.LogLevel = {}));


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Bus = (function () {
    function Bus() {
        var _this = this;
        this._subscriptions = [];
        chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
            if (typeof request.type === "undefined")
                return;
            _this._subscriptions
                .filter(function (s) {
                return s.type === request.type;
            })
                .forEach(function (s) {
                s.callback(request.message);
            });
        });
    }
    Bus.prototype.on = function (type, callback) {
        this._subscriptions.push({ type: type, callback: callback });
    };
    Bus.prototype.send = function (type, message) {
        this._subscriptions
            .filter(function (s) { return s.type === type; })
            .forEach(function (s) {
            s.callback(message);
        });
        chrome.runtime.sendMessage({ type: type, message: message }, function (response) { });
    };
    return Bus;
}());
exports.Bus = Bus;


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var Storage = (function () {
    function Storage() {
    }
    Storage.Get = function (key) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                return [2, new Promise(function (resolve, reject) {
                        chrome.storage.local.get(key, function (flag) {
                            resolve(flag[key]);
                        });
                    })];
            });
        });
    };
    Storage.Set = function (key, value) {
        chrome.storage.local.set((_a = {}, _a[key] = value, _a));
        var _a;
    };
    Storage.Remove = function (key) {
        chrome.storage.local.remove(key);
    };
    return Storage;
}());
exports.Storage = Storage;


/***/ }),
/* 3 */,
/* 4 */,
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = y[op[0] & 2 ? "return" : op[0] ? "throw" : "next"]) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [0, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var asynchrome_1 = __webpack_require__(6);
var logger_1 = __webpack_require__(0);
var message_bus_1 = __webpack_require__(1);
var storage_1 = __webpack_require__(2);
var utils_1 = __webpack_require__(7);
var Process = (function () {
    function Process() {
        var _this = this;
        this._bus = new message_bus_1.Bus();
        this._logger = new logger_1.Logger("Backgroud Process");
        this.heartBeatInterval = null;
        this.tabId = null;
        this._cacheArtist = null;
        this._cacheTitle = null;
        this.registerHotKeys();
        this.subscribe();
        (function () { return __awaiter(_this, void 0, void 0, function () { return __generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4, this.heartBeat()];
                case 1:
                    _a.sent();
                    return [2];
            }
        }); }); })();
        this._heartBeatInterval = setInterval(function () {
            (function () { return __awaiter(_this, void 0, void 0, function () { return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, this.heartBeat()];
                    case 1:
                        _a.sent();
                        return [2];
                }
            }); }); })();
        }, 700);
    }
    Process.prototype.plantAgent = function () {
        return __awaiter(this, void 0, void 0, function () {
            var tabs;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this._logger.info("Planting Agent");
                        return [4, asynchrome_1.Tabs.query({ url: "https://open.spotify.com/*" })];
                    case 1:
                        tabs = _a.sent();
                        if (!(tabs.length < 1)) return [3, 3];
                        return [4, asynchrome_1.Tabs.query({ url: "https://play.spotify.com/*" })];
                    case 2:
                        tabs = _a.sent();
                        _a.label = 3;
                    case 3:
                        if (!(tabs.length < 1)) return [3, 5];
                        return [4, asynchrome_1.Tabs.query({ url: "https://player.spotify.com/*" })];
                    case 4:
                        tabs = _a.sent();
                        _a.label = 5;
                    case 5:
                        if (tabs.length < 1) {
                            this._logger.error("Spotify tab not found");
                            return [2];
                        }
                        this.tabId = tabs[0].id;
                        this._logger.debug("Tab ID " + this.tabId);
                        return [2];
                }
            });
        });
    };
    Process.prototype.registerHotKeys = function () {
        var _this = this;
        this._logger.info("Registering hotkeys");
        chrome.commands.onCommand.addListener(function (cmd) {
            switch (cmd) {
                case "player-toggle":
                    _this._bus.send("idea.cmd.player.toggle");
                    break;
                case "player-next":
                    _this._bus.send("idea.cmd.player.next");
                    break;
                case "player-previous":
                    _this._bus.send("idea.cmd.player.previous");
                    break;
                case "player-mute":
                    _this._bus.send("idea.cmd.player.mute");
                    break;
                case "player-shuffle":
                    _this._bus.send("idea.cmd.player.shuffle");
                    break;
                case "player-repeat":
                    _this._bus.send("idea.cmd.player.repeat");
                    break;
                case "player-save":
                    _this._bus.send("idea.cmd.player.save");
                    break;
                default:
                    break;
            }
        });
        chrome.notifications.onClicked.addListener(function (evt) {
            _this._bus.send("idea.cmd.player.next");
        });
    };
    Process.prototype.subscribe = function () {
        var _this = this;
        this._logger.info("Subscribing");
        this._bus.on("idea.cmd.player.toggle", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Toggle()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.next", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Next()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.previous", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Previous()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.shuffle", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Shuffle()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.repeat", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Repeat()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.mute", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Mute()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.cmd.player.save", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!this.tabId)
                            return [2];
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.Save()" })];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.track.changed", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            var options, notificationId;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, storage_1.Storage.Get("notifications-disabled")];
                    case 1:
                        if (_a.sent()) {
                            this._logger.info("Notifications disabled - skipping");
                            return [2];
                        }
                        this._logger.info("Notifications enabled - displaying");
                        options = {
                            type: "basic",
                            iconUrl: evt.art,
                            title: evt.title,
                            message: evt.artist,
                            contextMessage: "(click to skip)",
                            isClickable: true
                        };
                        return [4, asynchrome_1.Notifications.create(utils_1.newGuid(), options)];
                    case 2:
                        notificationId = _a.sent();
                        return [4, utils_1.delay(5000)];
                    case 3:
                        _a.sent();
                        return [4, asynchrome_1.Notifications.clear(notificationId)];
                    case 4:
                        _a.sent();
                        return [2];
                }
            });
        }); });
        this._bus.on("idea.track.changed", function (evt) { return __awaiter(_this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4, this.getLyrics(evt.artist, evt.title)];
                    case 1:
                        _a.sent();
                        return [2];
                }
            });
        }); });
    };
    Process.prototype.getLyrics = function (artist, title) {
        return __awaiter(this, void 0, void 0, function () {
            var response, data, song, lyric, lines, lyr, i;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this._logger.info("Getting lyrics");
                        return [4, window.fetch("http://lyrics.wikia.com/api.php?action=lyrics&artist=" + artist + "&song=" + title + "&fmt=json")];
                    case 1:
                        response = _a.sent();
                        return [4, response.text()];
                    case 2:
                        data = _a.sent();
                        song = eval(data);
                        lyric = song;
                        if (!(lyric.lyrics.toLowerCase() === "not found")) return [3, 5];
                        storage_1.Storage.Remove("lyric");
                        if (!(title.indexOf(" - ") > -1)) return [3, 4];
                        return [4, this.getLyrics(artist, title.substring(0, title.indexOf(" - ")))];
                    case 3:
                        _a.sent();
                        _a.label = 4;
                    case 4: return [3, 6];
                    case 5:
                        lines = lyric.lyrics
                            .split(/\r\n|\r|\n/)
                            .filter(function (line) { return line.replace(/\s/g, "") === "" ? false : true; })
                            .splice(0, 4);
                        lyr = "";
                        for (i in lines) {
                            if (lines.hasOwnProperty(i)) {
                                if (lyr.length > 120)
                                    break;
                                lyr += ("\r\n" + lines[i].replace("[...]", ""));
                            }
                        }
                        lyric.lyrics = lyr + "..";
                        storage_1.Storage.Set("lyric", lyric);
                        _a.label = 6;
                    case 6: return [2];
                }
            });
        });
    };
    Process.prototype.heartBeat = function () {
        return __awaiter(this, void 0, void 0, function () {
            var tab, tracks, track;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        this._logger.debug("Heartbeat");
                        if (!!this.tabId) return [3, 2];
                        this._logger.warn("Tab ID not set");
                        return [4, this.plantAgent()];
                    case 1:
                        _a.sent();
                        return [2];
                    case 2: return [4, asynchrome_1.Tabs.get(this.tabId)];
                    case 3:
                        tab = _a.sent();
                        if (!!tab) return [3, 5];
                        this.tabId = null;
                        this._logger.warn("Tab ID not found", { tabId: this.tabId });
                        return [4, this.plantAgent()];
                    case 4:
                        _a.sent();
                        return [2];
                    case 5:
                        this._logger.debug("Tab ID found", { tabId: this.tabId });
                        return [4, asynchrome_1.Tabs.executeScript(this.tabId, { code: "agent.GetTrackInfo()" })];
                    case 6:
                        tracks = (_a.sent());
                        if (!(!tracks || tracks.length < 1 || !tracks[0])) return [3, 8];
                        this._logger.debug("Agent returned no track info", { tabId: this.tabId, tracks: tracks });
                        return [4, this.plantAgent()];
                    case 7:
                        _a.sent();
                        return [2];
                    case 8:
                        track = tracks[0];
                        this._bus.send("idea.track.updated", track);
                        if (this._cacheArtist !== track.artist || this._cacheTitle !== track.title) {
                            this._cacheArtist = track.artist;
                            this._cacheTitle = track.title;
                            this._bus.send("idea.track.changed", track);
                        }
                        return [2];
                }
            });
        });
    };
    return Process;
}());
var process = new Process();


/***/ }),
/* 6 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Tabs = (function () {
    function Tabs() {
    }
    Tabs.get = function (tabId) {
        return new Promise(function (resolve, reject) {
            chrome.tabs.get(tabId, function (tab) {
                resolve(tab);
            });
        });
    };
    Tabs.query = function (queryInfo) {
        return new Promise(function (resolve, reject) {
            chrome.tabs.query(queryInfo, function (tabs) {
                resolve(tabs);
            });
        });
    };
    Tabs.executeScript = function (tabId, details) {
        return new Promise(function (resolve, reject) {
            chrome.tabs.executeScript(tabId, details, function (tabs) {
                resolve(tabs);
            });
        });
    };
    return Tabs;
}());
exports.Tabs = Tabs;
var Notifications = (function () {
    function Notifications() {
    }
    Notifications.clear = function (notificationId) {
        return new Promise(function (resolve, reject) {
            chrome.notifications.clear(notificationId, function (isCleared) {
                resolve(isCleared);
            });
        });
    };
    Notifications.create = function (notificationId, options) {
        return new Promise(function (resolve, reject) {
            chrome.notifications.create(notificationId, options, function (id) {
                resolve(id);
            });
        });
    };
    return Notifications;
}());
exports.Notifications = Notifications;


/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
function newGuid() {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return s4() + s4() + "-" + s4() + "-" + s4() + "-" +
        s4() + "-" + s4() + s4() + s4();
}
exports.newGuid = newGuid;
function delay(ms) {
    return new Promise(function (resolve) {
        setTimeout(resolve, ms);
    });
}
exports.delay = delay;


/***/ })
/******/ ]);
//# sourceMappingURL=background.js.map