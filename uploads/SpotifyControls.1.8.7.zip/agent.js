/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 8);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var __assign = (this && this.__assign) || Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
            t[p] = s[p];
    }
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
var Logger = (function () {
    function Logger(name) {
        this._name = name;
    }
    Object.defineProperty(Logger.prototype, "_level", {
        get: function () {
            return window.logLevel || LogLevel.Debug;
        },
        enumerable: true,
        configurable: true
    });
    Logger.prototype.debug = function (message, params) {
        if (this._level > LogLevel.Debug)
            return;
        console.log(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    Logger.prototype.info = function (message, params) {
        if (this._level > LogLevel.Info)
            return;
        console.info(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    Logger.prototype.warn = function (message, params) {
        if (this._level > LogLevel.Warn)
            return;
        console.warn(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    Logger.prototype.error = function (message, params) {
        if (this._level > LogLevel.Error)
            return;
        console.error(message, __assign({ timestamp: new Date(), component: this._name }, params));
    };
    return Logger;
}());
exports.Logger = Logger;
var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["None"] = 0] = "None";
    LogLevel[LogLevel["Debug"] = 1] = "Debug";
    LogLevel[LogLevel["Info"] = 2] = "Info";
    LogLevel[LogLevel["Warn"] = 3] = "Warn";
    LogLevel[LogLevel["Error"] = 4] = "Error";
})(LogLevel = exports.LogLevel || (exports.LogLevel = {}));


/***/ }),

/***/ 1:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Bus = (function () {
    function Bus() {
        var _this = this;
        this._subscriptions = [];
        chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
            if (typeof request.type === "undefined")
                return;
            _this._subscriptions
                .filter(function (s) {
                return s.type === request.type;
            })
                .forEach(function (s) {
                s.callback(request.message);
            });
        });
    }
    Bus.prototype.on = function (type, callback) {
        this._subscriptions.push({ type: type, callback: callback });
    };
    Bus.prototype.send = function (type, message) {
        this._subscriptions
            .filter(function (s) { return s.type === type; })
            .forEach(function (s) {
            s.callback(message);
        });
        chrome.runtime.sendMessage({ type: type, message: message }, function (response) { });
    };
    return Bus;
}());
exports.Bus = Bus;


/***/ }),

/***/ 8:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var logger_1 = __webpack_require__(0);
var message_bus_1 = __webpack_require__(1);
var Agent = (function () {
    function Agent() {
        var _this = this;
        this._player = document.querySelector(".now-playing-bar");
        this._logger = new logger_1.Logger("Agent");
        this._bus = new message_bus_1.Bus();
        this._track = {};
        this._clickAt = function (elem, x) {
            _this._logger.info("rewinding to width" + x);
            _this._logger.info("rewinding to offset" + (elem.offsetLeft + x));
            var evt = document.createEvent("MouseEvents");
            evt.initMouseEvent("click", true, true, window, 0, elem.offsetLeft + x, 0, x, 6, false, false, false, false, 0, undefined);
            elem.dispatchEvent(evt);
        };
        this._logger.info("Agent planted");
    }
    Agent.prototype.isReady = function () {
        if (!this._player)
            this._player = document.querySelector(".now-playing-bar");
        if (!this._player)
            return false;
        return true;
    };
    Agent.prototype.GetTrackInfo = function () {
        if (!this.isReady())
            return undefined;
        return {
            artist: this.GetArtist(),
            title: this.GetTitle(),
            art: this.GetArt(),
            progress: this.GetProgress(),
            elapsed: this.GetElapsed(),
            length: this.GetLength(),
            volume: this.GetVolume(),
            shuffle_on: this.GetShuffleState(),
            repeat_on: this.GetRepeatState(),
            mute_on: this.GetMuteState(),
            is_playing: this.GetPlayState(),
            is_saved: this.GetSavedState()
        };
    };
    Agent.prototype.Toggle = function () {
        var playButton = this._player.querySelector(".spoticon-pause-16");
        if (!playButton)
            playButton = this._player.querySelector(".spoticon-play-16");
        playButton.click();
    };
    Agent.prototype.Next = function () {
        this._player.querySelector(".spoticon-skip-forward-16").click();
    };
    Agent.prototype.Previous = function () {
        this._player.querySelector(".spoticon-skip-back-16").click();
    };
    Agent.prototype.Repeat = function () {
        (this._player.querySelector(".spoticon-repeat-16") || this._player.querySelector(".spoticon-repeatonce-16")).click();
    };
    Agent.prototype.Shuffle = function () {
        this._player.querySelector(".spoticon-shuffle-16").click();
    };
    Agent.prototype.Mute = function () {
        this._player.querySelector(".volume-bar button").click();
    };
    Agent.prototype.Save = function () {
        var saveButton = this._player.querySelector(".spoticon-heart-16");
        var unsaveButton = this._player.querySelector(".spoticon-heart-active-16");
        (saveButton || unsaveButton).click();
        this._bus.send("idea.evt.player.saved", {
            feedback: saveButton ? "Added to your Favorite Songs" : "Removed from your Favorite Songs",
            song: this.GetArtist() + " - " + this.GetTitle(),
            art: this.GetArt()
        });
    };
    Agent.prototype.Rewind = function (target) {
        var elem = this._player.querySelector(".progress-bar");
        this._logger.info(elem);
        this._logger.info("rewinding to target" + target);
        this._clickAt(elem, elem.offsetWidth * target);
    };
    Agent.prototype.GetArtist = function () {
        try {
            return this._player.querySelector(".track-info__artists a").text;
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetTitle = function () {
        try {
            return this._player.querySelector(".track-info__name a").text;
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetArt = function () {
        try {
            var art = this._player.querySelector(".cover-art-image").style.backgroundImage;
            return art.slice(5, art.length - 2);
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetProgress = function () {
        try {
            var t1 = this.GetElapsed().split(":").map(function (t) { return ~~t; });
            var elapsed = t1[0] * 60 + t1[1];
            var t2 = this.GetLength().split(":").map(function (t) { return ~~t; });
            var total = t2[0] > 0 ? t2[0] * 60 + t2[1] : t2[0] * 60 * -1 + t2[1] + elapsed;
            return elapsed / total;
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetElapsed = function () {
        try {
            return this._player.querySelector(".playback-bar__progress-time").innerHTML;
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetLength = function () {
        try {
            var all = this._player.querySelectorAll(".playback-bar__progress-time");
            return all[all.length - 1].innerHTML;
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetVolume = function () {
        try {
            return ~~(this._player.querySelector(".volume-bar .progress-bar__slider").style.left.replace("%", "")) / 100;
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetShuffleState = function () {
        try {
            var shuffleButton = this._player.querySelector(".spoticon-shuffle-16");
            return shuffleButton.classList.contains("control-button--active");
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetRepeatState = function () {
        try {
            var repeatButton = this._player.querySelector(".spoticon-repeat-16");
            if (!repeatButton)
                repeatButton = this._player.querySelector(".spoticon-repeatonce-16");
            return repeatButton.classList.contains("control-button--active");
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetMuteState = function () {
        try {
            var repeatButton = this._player.querySelector(".volume-bar button");
            return repeatButton.classList.contains("spoticon-volume-off-16");
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetPlayState = function () {
        try {
            return !!this._player.querySelector(".spoticon-pause-16");
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetSavedState = function () {
        try {
            return !!this._player.querySelector(".spoticon-heart-active-16");
        }
        catch (error) {
            return undefined;
        }
    };
    return Agent;
}());
window.agent = new Agent();


/***/ })

/******/ });
//# sourceMappingURL=agent.js.map