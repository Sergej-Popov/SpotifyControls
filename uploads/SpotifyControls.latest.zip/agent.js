/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 6);
/******/ })
/************************************************************************/
/******/ ({

/***/ 6:
/***/ (function(module, exports, __webpack_require__) {

"use strict";

Object.defineProperty(exports, "__esModule", { value: true });
var Agent = (function () {
    function Agent() {
        this._player = document.querySelector(".now-playing-bar");
        this._track = {};
        this._clickAt = function (elem, x) {
            console.log("rewinding to width" + x);
            console.log("rewinding to offset" + (elem.offsetLeft + x));
            var evt = document.createEvent("MouseEvents");
            evt.initMouseEvent("click", true, true, window, 0, elem.offsetLeft + x, 0, x, 6, false, false, false, false, 0, undefined);
            elem.dispatchEvent(evt);
        };
    }
    Agent.prototype.isReady = function () {
        if (!this._player)
            return false;
        return true;
    };
    Agent.prototype.GetTrackInfo = function () {
        if (!this.isReady())
            return undefined;
        return {
            artist: this.GetArtist(),
            title: this.GetTitle(),
            art: this.GetArt(),
            progress: this.GetProgress(),
            elapsed: this.GetElapsed(),
            length: this.GetLength(),
            volume: this.GetVolume(),
            shuffle_on: this.GetShuffleState(),
            repeat_on: this.GetRepeatState(),
            mute_on: this.GetMuteState()
        };
    };
    Agent.prototype.Toggle = function () {
        var playButton = this._player.querySelector('.spoticon-pause-16');
        if (!playButton)
            playButton = this._player.querySelector('.spoticon-play-16');
        playButton.click();
    };
    ;
    Agent.prototype.Next = function () {
        this._player.querySelector(".spoticon-skip-forward-16").click();
    };
    ;
    Agent.prototype.Previous = function () {
        this._player.querySelector(".spoticon-skip-back-16").click();
    };
    ;
    Agent.prototype.Repeat = function () {
        this._player.querySelector(".spoticon-repeat-16").click();
    };
    ;
    Agent.prototype.Shuffle = function () {
        this._player.querySelector(".spoticon-shuffle-16").click();
    };
    ;
    Agent.prototype.Mute = function () {
        this._player.querySelector(".volume-bar button").click();
    };
    ;
    Agent.prototype.Rewind = function (target) {
        var elem = this._player.querySelector('.progress-bar');
        console.log(elem);
        console.log("rewinding to target" + target);
        this._clickAt(elem, elem.offsetWidth * target);
    };
    ;
    Agent.prototype.GetArtist = function () {
        try {
            return this._player.querySelector(".track-info__artists a").text;
        }
        catch (error) {
            return undefined;
        }
    };
    ;
    Agent.prototype.GetTitle = function () {
        try {
            return this._player.querySelector(".track-info__name a").text;
        }
        catch (error) {
            return undefined;
        }
    };
    ;
    Agent.prototype.GetArt = function () {
        try {
            var art = this._player.querySelector(".cover-art-image").style.backgroundImage;
            return art.slice(5, art.length - 2);
        }
        catch (error) {
            return undefined;
        }
    };
    ;
    Agent.prototype.GetProgress = function () {
        try {
            var t1 = this.GetElapsed().split(":").map(function (t) { return parseInt(t); });
            var elapsed = t1[0] * 60 + t1[1];
            var t2 = this.GetLength().split(":").map(function (t) { return parseInt(t); });
            var total = t2[0] > 0 ? t2[0] * 60 + t2[1] : t2[0] * 60 * -1 + t2[1] + elapsed;
            return elapsed / total;
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetElapsed = function () {
        try {
            return this._player.querySelector(".playback-bar__progress-time").innerHTML;
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetLength = function () {
        try {
            return this._player.querySelector(".progress-bar + .playback-bar__progress-time").innerHTML;
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetVolume = function () {
        try {
            return parseInt(this._player.querySelector(".volume-bar .progress-bar__slider").style.left.replace("%", "")) / 100;
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetShuffleState = function () {
        try {
            var shuffleButton = this._player.querySelector(".spoticon-shuffle-16");
            return shuffleButton.classList.contains("control-button--active");
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetRepeatState = function () {
        try {
            var repeatButton = this._player.querySelector(".spoticon-repeat-16");
            return repeatButton.classList.contains("control-button--active");
        }
        catch (error) {
            return undefined;
        }
    };
    Agent.prototype.GetMuteState = function () {
        try {
            var repeatButton = this._player.querySelector(".volume-bar button");
            return repeatButton.classList.contains("spoticon-volume-off-16");
        }
        catch (error) {
            return undefined;
        }
    };
    return Agent;
}());
window.agent = new Agent();


/***/ })

/******/ });
//# sourceMappingURL=agent.js.map